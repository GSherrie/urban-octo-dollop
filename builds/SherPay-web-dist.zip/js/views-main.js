/* ============ SherPay views: Dashboard, Invoices list, Client invoice view, Receipt ============ */
(function () {
  const S = window.Store, UI = window.UI;
  const icon = UI.icon, esc = S.esc;

  /* ---------- setup loop card (Zeigarnik + Hick) ---------------------------
     Every milestone is derived from data the user actually entered, so the card
     cannot lie about progress. Only the next undone step is offered as a call to
     action — finished steps collapse to a tick and later steps stay quiet, so
     the card never turns into a five-button decision menu. */
  function setupCard(p, blank) {
    let nextSeen = false;
    const rows = p.steps.map((s) => {
      const cls = s.done ? 'ok' : (!nextSeen ? (nextSeen = true, 'next') : 'later');
      return '<button class="loop-step ' + cls + '" data-action="setup-step" data-href="' + s.href + '">' +
        '<span class="tick">' + icon('check') + '</span>' +
        '<span style="flex:1;min-width:0"><b>' + esc(s.label) + '</b>' + (cls === 'next' ? '<div class="tiny muted">' + esc(s.hint) + '</div>' : '') + '</span>' +
        '<span class="go">' + (s.done ? 'Done' : cls === 'next' ? 'Do next' : 'Later') + '</span>' +
        '</button>';
    }).join('');
    return '<div class="card loop-card">' +
      '<div class="loop-h"><h3>' + (blank ? 'Welcome to SherPay — your first payment is a few taps away' : 'Finish setting up SherPay') + '</h3>' +
        '<div class="prog-line"><div class="prog"><i style="width:' + p.pct + '%"></i></div>' +
        '<span class="of">' + p.done + ' of ' + p.total + '</span></div></div>' +
      '<div class="loop-steps">' + rows + '</div>' +
      '<div class="loop-foot">' +
        (blank ? 'Nothing is pre-filled — this is your real workspace. ' : 'This card closes itself when every step is done. ') +
        (blank ? '<button class="btn sm ghost" data-action="load-demo">' + icon('play') + 'Explore with sample data</button>' : '') +
      '</div></div>';
  }

  /* ---------- unfinished work (Zeigarnik): pick up the draft you left ------ */
  function resumeStrip(drafts) {
    return '<div class="resume"><span class="rl">' + icon('edit') + 'Unfinished drafts</span>' +
      drafts.map((i) => {
        const c = S.getClient(i.clientId), t = S.computeTotals(i);
        return '<button class="rb" data-action="edit-draft" data-id="' + i.id + '">' + esc(i.number) +
          ' · ' + esc(c ? c.name : 'No client') + ' <span class="tnum tiny">' + S.fmtMoney(t.total, i.currency) + '</span>' + icon('chevron') + '</button>';
      }).join('') + '</div>';
  }

  /* ================= DASHBOARD ================= */
  UI.VIEWS.dashboard = function () {
    const k = S.kpis();
    const cur = S.db.settings.currency;
    const mb = S.moneyByMonth();
    const counts = { draft: 0, sent: 0, viewed: 0, paid: 0, overdue: 0, partial: 0 };
    S.db.invoices.forEach((i) => counts[S.displayStatus(i)]++);
    const outstanding = S.db.invoices
      .filter((i) => !['paid', 'draft'].includes(S.displayStatus(i)))
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    const act = S.db.activity.slice(0, 7);
    const actIcon = { paid: ['wallet', 'var(--green-soft)', 'var(--green-dark)'], receipt: ['file', 'var(--green-soft)', 'var(--green-dark)'], viewed: ['eye', 'var(--violet-soft)', 'var(--on-violet-soft)'], sent: ['send', 'var(--blue-soft)', 'var(--on-blue-soft)'], reminder: ['bell', 'var(--amber-soft)', 'var(--on-amber-soft)'], recurring: ['repeat', 'var(--blue-soft)', 'var(--on-blue-soft)'], scan: ['scan', 'var(--blue-soft)', 'var(--on-blue-soft)'] };

    const blankWorkspace = !S.db.clients.length && !S.db.invoices.length && !S.db.expenses.length;
    /* Zeigarnik: an unfinished setup reads as an open loop, and an unfinished
       draft reads as work you were in the middle of. Both are shown above the
       fold and both disappear the moment they are closed. */
    const prog = S.setupProgress();
    const drafts = S.recentDrafts(3);
    return {
      title: 'Dashboard',
      sub: 'Business health at a glance — ' + new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' }),
      topActions: '<button class="btn ghost" data-action="scan">' + icon('scan') + '<span class="hide-sm">Scan receipt</span></button><button class="btn primary" data-action="new-invoice">' + icon('plus') + 'New invoice</button>',
      html:
        (prog.complete ? '' : setupCard(prog, blankWorkspace)) +
        (drafts.length ? resumeStrip(drafts) : '') +
        '<div class="grid kpis">' +
          '<div class="card kpi kpi-link accent-blue" data-action="open-outstanding" role="button" tabindex="0" aria-label="Outstanding — open all unpaid invoices"><div class="lab">' + icon('wallet') + 'Outstanding</div><div class="val">' + S.fmtMoney(k.outstanding, cur) + '</div><div class="delta">' + outstanding.length + ' open invoice' + (outstanding.length === 1 ? '' : 's') + '</div></div>' +
          '<div class="card kpi accent-green"><div class="lab">' + icon('check') + 'Collected this month</div><div class="val">' + S.fmtMoney(k.paidMonth, cur) + '</div><div class="delta">across all currencies (base ' + cur + ')</div></div>' +
          '<div class="card kpi kpi-link" data-action="open-expenses" role="button" tabindex="0" aria-label="Expenses this month — open expenses"><div class="lab">' + icon('expenses') + 'Expenses this month</div><div class="val">' + S.fmtMoney(k.expMonth, cur) + '</div><div class="delta">' + S.db.expenses.filter((e) => S.monthKey(e.date) === S.monthKey(S.todayISO())).length + ' receipts logged</div></div>' +
          '<div class="card kpi ' + (k.net >= 0 ? 'accent-green' : 'accent-red') + '"><div class="lab">' + icon('reports') + 'Net profit (month)</div><div class="val">' + S.fmtMoney(k.net, cur) + '</div><div class="delta">revenue − expenses</div></div>' +
        '</div>' +
        '<div class="grid two mt2">' +
          '<div class="card"><div class="card-h"><h3>Cash flow — last 6 months</h3><div class="spacer"></div><span class="chip" style="border:none;background:var(--blue-soft);color:var(--on-blue-soft)">■ Collected</span><span class="chip" style="border:none;background:var(--seg-bg);color:var(--muted)">■ Spent</span></div><div class="card-b">' + UI.barChart(mb.months, mb.rev, mb.exp, cur) + '</div></div>' +
          '<div class="card"><div class="card-h"><h3>Pipeline</h3></div><div class="card-b row wrap" style="gap:18px">' + UI.donut(counts) +
            '<div class="grid" style="gap:7px;flex:1">' + Object.entries(counts).map(([kk, v]) => '<div class="row small"><span class="badge ' + kk + '" style="min-width:86px;justify-content:center">' + S.STATUS_LABEL[kk] + '</span><b class="tnum">' + v + '</b></div>').join('') + '</div></div></div>' +
        '</div>' +
        '<div class="grid two mt2">' +
          '<div class="card"><div class="card-h"><h3>Awaiting payment</h3><div class="spacer"></div>' + (k.overdueCount ? '<span class="badge overdue">' + k.overdueCount + ' overdue</span>' : '') + '</div>' +
            (outstanding.length ? outstanding.slice(0, 6).map((i) => {
              const c = S.getClient(i.clientId), t = S.computeTotals(i), st = S.displayStatus(i);
              const dd = S.daysBetween(S.todayISO(), i.dueDate);
              return '<div class="list-row' + (dd < 0 ? ' lr-overdue' : '') + '"><div data-action="open-invoice" data-id="' + i.id + '" style="display:flex;align-items:center;gap:12px;flex:1;cursor:pointer">' + UI.avatar(c ? c.name : '?') +
                '<div style="flex:1;min-width:0"><b class="small">' + esc(i.number) + ' · ' + esc(c ? c.name : '') + '</b><div class="tiny muted">Due ' + S.fmtDate(i.dueDate) + ' · ' + (dd < 0 ? '<b class="od">' + Math.abs(dd) + ' days overdue</b>' : dd === 0 ? 'due today' : dd + ' days left') + '</div></div>' +
                '<div style="text-align:right"><div class="tnum small">' + S.fmtMoney(t.balance, i.currency) + '</div>' + UI.badge(st) + '</div></div></div>';
            }).join('') : '<div class="empty">' + icon('check') + '<b>Nothing outstanding</b>Every invoice is settled. Lovely.</div>') +
          '</div>' +
          '<div class="card"><div class="card-h"><h3>Activity</h3><div class="spacer"></div><span class="tiny muted">auto-logged</span></div>' +
            (act.length ? act.map((a) => { const m = actIcon[a.type] || ['bell', 'var(--blue-soft)', 'var(--on-blue-soft)']; return '<div class="act-item"><span class="ico" style="background:' + m[1] + ';color:' + m[2] + '">' + icon(m[0]) + '</span><div style="flex:1">' + esc(a.message) + '<div><time>' + S.fmtDateTime(a.ts) + '</time></div></div></div>'; }).join('') : '<div class="empty">No activity yet</div>') +
          '</div>' +
        '</div>',
      actions: {
        'new-invoice': () => { location.hash = '#/invoices/new'; },
        'go-clients': () => { location.hash = '#/clients'; },
        'load-demo': () => UI.confirmDialog('Explore with sample data?', 'Replaces this workspace with example clients, invoices and expenses so you can look around. You can start fresh again afterwards by deleting the sample items.', () => { S.resetDemo(); UI.toast('Sample data loaded', 'green', 'sync'); UI.render(); }, 'Load sample'),
        scan: () => UI.VIEWS.expenses.__scan(),
        'open-invoice': (d) => { location.hash = '#/i/' + d.id; },
        'setup-step': (d) => { if (d.href) UI.go(d.href); },
        'edit-draft': (d) => { UI.go('#/invoices/' + d.id + '/edit'); },
        'open-outstanding': () => { UI.go('#/invoices'); },
        'open-expenses': () => { UI.go('#/expenses'); }
      }
    };
  };

  /* ================= INVOICES LIST ================= */
  UI.VIEWS.invoices = function () {
    let q = '', status = 'all', tailOpen = false;
    /* Hick: seven status chips all shouting is a menu, not a filter. The four
       people actually reach for stay visible, the tail tucks behind "More" and
       pops back out the moment one of them is the active filter. */
    const CHIP_CORE = ['all', 'draft', 'sent', 'overdue'];
    const CHIP_TAIL = ['viewed', 'partial', 'paid'];
    function chipBtn(s, hidden) {
      return '<button class="chip' + (status === s ? ' on' : '') + (hidden ? ' hidden' : '') + '" data-action="chip" data-s="' + s + '">' +
        (s === 'all' ? 'All' : S.STATUS_LABEL[s]) + '</button>';
    }
    function chipsHtml() {
      const expanded = tailOpen || CHIP_TAIL.indexOf(status) > -1;
      let out = CHIP_CORE.map((s) => chipBtn(s)).join('');
      out += CHIP_TAIL.map((s) => chipBtn(s, !expanded)).join('');
      out += expanded
        ? '<button class="chip more open" data-action="chip-more">Fewer</button>'
        : '<button class="chip more" data-action="chip-more" aria-label="Show ' + CHIP_TAIL.length + ' more status filters">More <span class="n">+' + CHIP_TAIL.length + '</span></button>';
      return out;
    }
    function refreshChips() {
      const box = document.getElementById('inv-chips');
      if (box) box.innerHTML = chipsHtml();
    }
    function rows() {
      return S.db.invoices.filter((i) => {
        const c = S.getClient(i.clientId), t = S.computeTotals(i);
        const hay = (i.number + ' ' + (c ? c.name + ' ' + (c.contact || '') : '') + ' ' + t.total).toLowerCase();
        return (status === 'all' || S.displayStatus(i) === status) && (!q || hay.includes(q.toLowerCase()));
      });
    }
    function tableHtml() {
      const list = rows();
      if (!list.length) return '<div class="empty">' + icon('invoice') + '<b>No invoices match</b>Try a different search or filter, or create a new invoice.</div>';
      return '<div class="scroll-x"><table class="table"><thead><tr><th>Invoice</th><th>Client</th><th class="hide-sm">Issued</th><th>Due</th><th>Status</th><th class="right">Total</th><th class="right hide-sm">Balance</th><th></th></tr></thead><tbody>' +
        list.map((i) => {
          const c = S.getClient(i.clientId), t = S.computeTotals(i), st = S.displayStatus(i);
          const od = st === 'overdue';
          /* Von Restorff: one red edge is the loudest thing in this table, and it
             is spent entirely on the thing that is actually wrong. */
          return '<tr class="clickable' + (od ? ' row-overdue' : '') + '" data-action="open-invoice" data-id="' + i.id + '">' +
            '<td><b>' + esc(i.number) + '</b>' + (i.recurring ? ' <span title="Recurring">' + icon('repeat') + '</span>' : '') + '</td>' +
            '<td><div class="row" style="gap:9px">' + UI.avatar(c ? c.name : '?') + '<span class="hide-sm">' + esc(c ? c.name : '—') + '</span></div></td>' +
            '<td class="hide-sm muted small">' + S.fmtDate(i.issueDate) + '</td>' +
            '<td class="small' + (od ? ' od' : '') + '">' + S.fmtDate(i.dueDate) + '</td>' +
            '<td>' + UI.badge(st) + '</td>' +
            '<td class="right tnum small">' + S.fmtMoney(t.total, i.currency) + '</td>' +
            '<td class="right tnum small hide-sm">' + (t.balance > 0 ? S.fmtMoney(t.balance, i.currency) : '—') + '</td>' +
            '<td class="right" style="white-space:nowrap">' +
              (st === 'draft' ? '<button class="btn sm ghost" data-action="send" data-id="' + i.id + '" aria-label="Send ' + esc(i.number) + '">' + icon('send') + 'Send</button>' : '') +
              (st !== 'paid' && st !== 'draft' ? '<button class="btn sm green" data-action="pay" data-id="' + i.id + '" aria-label="Record a payment on ' + esc(i.number) + '">' + icon('wallet') + '<span class="hide-sm">Payment</span></button>' : '') +
              '<button class="btn sm icon ghost" title="Edit" aria-label="Edit ' + esc(i.number) + '" data-action="edit" data-id="' + i.id + '">' + icon('edit') + '</button>' +
            '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    return {
      title: 'Invoices',
      sub: S.db.invoices.length + ' invoices · ' + S.db.invoices.filter((i) => S.displayStatus(i) === 'overdue').length + ' overdue',
      topActions: '<button class="btn primary" data-action="new-invoice">' + icon('plus') + 'New invoice</button>',
      html:
        '<div class="card"><div class="card-h" style="gap:9px;flex-wrap:wrap">' +
          '<div style="position:relative;flex:1;min-width:170px;max-width:330px"><input id="inv-q" class="input" style="padding-left:34px" placeholder="Search number, client, amount…" aria-label="Search invoices" inputmode="search" autocomplete="off"></div>' +
          '<div class="row wrap" id="inv-chips" style="gap:6px">' + chipsHtml() + '</div>' +
          '<div class="spacer"></div><button class="btn ghost sm" data-action="csv">' + icon('download') + 'CSV</button>' +
        '</div><div id="inv-table">' + tableHtml() + '</div></div>',
      mount: (root) => {
        root.querySelector('#inv-q').addEventListener('input', (e) => { q = e.target.value; root.querySelector('#inv-table').innerHTML = tableHtml(); });
        root.querySelector('#inv-q').style.background = '#fff url("data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#8A97A8" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>') + '") no-repeat 10px center / 16px';
      },
      actions: {
        'new-invoice': () => { location.hash = '#/invoices/new'; },
        chip: (d) => { status = d.s; refreshChips(); document.getElementById('inv-table').innerHTML = tableHtml(); },
        'chip-more': () => { tailOpen = !tailOpen; refreshChips(); },
        'open-invoice': (d) => { location.hash = '#/i/' + d.id; },
        edit: (d) => { location.hash = '#/invoices/' + d.id + '/edit'; },
        send: (d) => sendModal(d.id),
        pay: (d) => payModal(d.id),
        csv: () => {
          const rows = [['Number', 'Client', 'Status', 'Issued', 'Due', 'Currency', 'Subtotal', 'Discount', 'Tax', 'Total', 'Paid', 'Balance']];
          S.db.invoices.forEach((i) => { const c = S.getClient(i.clientId), t = S.computeTotals(i); rows.push([i.number, c ? c.name : '', S.STATUS_LABEL[S.displayStatus(i)], i.issueDate, i.dueDate, i.currency, t.sub.toFixed(2), t.disc.toFixed(2), t.tax.toFixed(2), t.total.toFixed(2), t.paid.toFixed(2), t.balance.toFixed(2)]); });
          S.download('sherpay-invoices-' + S.todayISO() + '.csv', S.toCSV(rows), 'text/csv');
          UI.toast('Invoices exported to CSV', 'green', 'download');
        }
      }
    };
  };

  /* ================= send modal ================= */
  function sendModal(id) {
    const inv = S.getInvoice(id); if (!inv) return;
    const c = S.getClient(inv.clientId), t = S.computeTotals(inv);
    // derive from href (not location.origin) so the link also works from
    // file:// (single-file offline build), where origin is the string "null"
    const link = location.href.split('#')[0] + '#/i/' + inv.id;
    UI.openModal({
      title: 'Send ' + inv.number,
      body: '<p class="small muted mb">Deliver a pay-link to <b>' + esc(c ? c.name : 'client') + '</b> — ' + S.fmtMoney(t.balance, inv.currency) + ' due. Opening the link marks the invoice <b>Viewed</b>; paying flips it to <b>Paid</b> and auto-issues a receipt.</p>' +
        '<div class="grid" style="gap:9px">' +
        '<button class="method on" data-action="ch" data-m="Email"><span class="mico" style="background:#0B7CFF">' + icon('mail') + '</span><span><b>Email</b><div class="tiny muted">' + esc(c ? c.email : '') + ' · branded pay-link + PDF</div></span></button>' +
        '<button class="method" data-action="ch" data-m="WhatsApp"><span class="mico" style="background:#25D366">' + icon('msg') + '</span><span><b>WhatsApp</b><div class="tiny muted">Share invoice link in chat</div></span></button>' +
        '<button class="method" data-action="ch" data-m="SMS / iMessage"><span class="mico" style="background:#7C6BF2">' + icon('msg') + '</span><span><b>SMS / iMessage</b><div class="tiny muted">' + esc(c ? c.phone : '') + '</div></span></button>' +
        '<div class="method" style="cursor:default"><span class="mico" style="background:#0A2E5F">' + icon('link') + '</span><span style="flex:1;min-width:0"><b class="tiny" style="word-break:break-all">' + link + '</b></span><button class="btn sm ghost" data-action="copylink">' + icon('copy') + 'Copy</button></div>' +
        '</div>' +
        '<div class="row mt" style="gap:8px">' + icon('bell') + '<span class="small muted">Reminders auto-send ' + S.db.settings.reminderDays.map((d) => d > 0 ? d + 'd before' : d === 0 ? 'on due date' : Math.abs(d) + 'd after').join(', ') + '.</span></div>',
      footer: '<button class="btn ghost" data-action="close-modal">Cancel</button><button class="btn primary" id="do-send">' + icon('send') + 'Send invoice</button>',
      mount: (m) => {
        let channel = 'Email';
        m.querySelectorAll('[data-action="ch"]').forEach((b) => b.addEventListener('click', () => { channel = b.dataset.m; m.querySelectorAll('.method').forEach((x) => x.classList.remove('on')); b.classList.add('on'); }));
        m.querySelector('[data-action="copylink"]').addEventListener('click', () => { UI.copyText(link).then((ok) => UI.toast(ok ? 'Pay-link copied' : 'Copy blocked — select the link manually', ok ? 'green' : 'red', 'link')); });
        m.querySelector('#do-send').addEventListener('click', () => {
          S.markSent(inv.id, channel);
          UI.closeModal(); UI.toast(inv.number + ' sent via ' + channel, 'green', 'send');
          UI.render();
        });
      }
    });
  }

  /* ================= pay modal ================= */
  function payModal(id) {
    const inv = S.getInvoice(id); if (!inv) return;
    const t = S.computeTotals(inv);
    UI.openModal({
      title: 'Record payment — ' + inv.number,
      body: '<div class="fgrid c2 mb"><div><label class="f">Amount (' + inv.currency + ')</label><input id="pm-amt" class="input" type="number" step="0.01" value="' + t.balance + '"></div><div><label class="f">Date</label><input id="pm-date" class="input" type="date" value="' + S.todayISO() + '"></div></div>' +
        '<label class="f">Method</label><div class="grid" style="gap:8px" id="pm-methods">' + S.PAY_METHODS.map((p, ix) => '<button class="method' + (ix === 0 ? ' on' : '') + '" data-m="' + p.id + '"><span class="mico" style="background:' + p.color + '">' + p.tag + '</span><span><b>' + p.label + '</b><div class="tiny muted">' + p.note + '</div></span></button>').join('') + '</div>' +
        '<p class="hint">Partial payments are supported — the invoice stays open with its balance until fully settled.</p>',
      footer: '<button class="btn ghost" data-action="close-modal">Cancel</button><button class="btn green" id="pm-save">' + icon('check') + 'Record payment</button>',
      mount: (m) => {
        let method = S.PAY_METHODS[0].id;
        m.querySelectorAll('#pm-methods .method').forEach((b) => b.addEventListener('click', () => { method = b.dataset.m; m.querySelectorAll('#pm-methods .method').forEach((x) => x.classList.remove('on')); b.classList.add('on'); }));
        m.querySelector('#pm-save').addEventListener('click', () => {
          const res = S.recordPayment(inv.id, m.querySelector('#pm-amt').value, method, m.querySelector('#pm-date').value);
          UI.closeModal();
          if (!res) { UI.toast('Invalid amount', 'red'); return; }
          UI.toast(res.receipt ? 'Paid in full — receipt ' + res.receipt + ' issued' : 'Payment recorded — balance ' + S.fmtMoney(res.balance, inv.currency), 'green', 'wallet');
          UI.render();
        });
      }
    });
  }

  /* ================= CLIENT-FACING INVOICE ================= */
  UI.VIEWS.i = function (parts) {
    const inv = S.getInvoice(parts[1]);
    if (!inv) return { title: 'Not found', html: '<div class="empty">Invoice not found.</div>', actions: {} };
    S.markViewed(inv.id); // "Viewed" tracking when the pay-link is opened
    const c = S.getClient(inv.clientId), b = S.db.settings.business, t = S.computeTotals(inv), st = S.displayStatus(inv);
    const tpl = S.db.settings.template;
    const logo = b.logoDataUrl || 'assets/logo.png';
    document.title = inv.number + ' — SherPay';

    return {
      title: inv.number,
      sub: 'Client view · pay-link',
      topActions: '<button class="btn ghost" data-action="back">' + icon('chevron', 'flip') + '<span class="hide-sm">Back</span></button><button class="btn ghost" data-action="edit">' + icon('edit') + '<span class="hide-sm">Edit</span></button><button class="btn ghost" data-action="pdf">' + icon('print') + '<span class="hide-sm">PDF</span></button>' + (st !== 'paid' && st !== 'draft' ? '<button class="btn green" data-action="pay">' + icon('wallet') + '<span class="hide-sm">Payment</span></button>' : ''),
      html:
        '<div class="paper font-' + tpl.font + ' acc-' + tpl.accent + '" id="paper">' +
          '<div class="paper-top"><div class="paper-brand"><img src="' + logo + '" alt=""><div><div class="bn">' + esc(b.name) + '</div><div class="ba">' + esc(b.address) + '\n' + esc(b.email) + ' · ' + esc(b.phone) + '</div></div></div>' +
          '<div class="paper-title"><h2>INVOICE</h2><div class="pnum">' + esc(inv.number) + '</div><div class="mt">' + UI.badge(st) + '</div></div></div>' +
          '<div class="paper-meta">' +
            '<div><div class="k">Billed to</div><div class="v">' + esc(c ? c.name : '') + '\n' + esc(c ? c.contact || '' : '') + '\n' + esc(c ? c.address || '' : '') + '</div></div>' +
            '<div><div class="k">Issued</div><div class="v">' + S.fmtDate(inv.issueDate) + '</div></div>' +
            '<div><div class="k">Due</div><div class="v">' + S.fmtDate(inv.dueDate) + '</div></div>' +
            '<div><div class="k">Currency</div><div class="v">' + inv.currency + '</div></div>' +
          '</div>' +
          '<table><thead><tr><th>Description</th><th class="right">Qty</th><th class="right">Unit price</th><th class="right">Amount</th></tr></thead><tbody>' +
          inv.items.map((it) => '<tr><td>' + esc(it.desc) + '</td><td class="right">' + it.qty + '</td><td class="right">' + S.fmtMoney(it.price, inv.currency) + '</td><td class="right tnum">' + S.fmtMoney(S.num(it.qty) * S.num(it.price), inv.currency) + '</td></tr>').join('') +
          '</tbody></table>' +
          '<div class="paper-totals"><table>' +
            '<tr><td>Subtotal</td><td class="right tnum">' + S.fmtMoney(t.sub, inv.currency) + '</td></tr>' +
            (t.disc ? '<tr><td>Discount' + (inv.discountMode === 'percent' ? ' (' + inv.discountValue + '%)' : '') + '</td><td class="right tnum">−' + S.fmtMoney(t.disc, inv.currency) + '</td></tr>' : '') +
            (t.tax ? '<tr><td>' + esc(S.db.settings.taxLabel) + (inv.taxMode === 'percent' ? ' (' + inv.taxValue + '%)' : '') + '</td><td class="right tnum">' + S.fmtMoney(t.tax, inv.currency) + '</td></tr>' : '') +
            '<tr class="grand"><td>Total due</td><td class="right tnum">' + S.fmtMoney(t.total, inv.currency) + '</td></tr>' +
            (t.paid ? '<tr><td class="muted">Paid to date</td><td class="right tnum muted">−' + S.fmtMoney(t.paid, inv.currency) + '</td></tr><tr><td class="muted">Balance</td><td class="right tnum" style="color:var(--acc)">' + S.fmtMoney(t.balance, inv.currency) + '</td></tr>' : '') +
          '</table></div>' +
          (inv.notes ? '<div class="paper-notes">' + esc(inv.notes) + '</div>' : '') +
          '<div class="paper-foot"><img src="assets/logo.png" alt=""> Powered by <b>SherPay</b> — invoicing, receipts & payments</div>' +
        '</div>' +
        (st !== 'paid' && st !== 'draft' ? '<div class="pay-bar no-print"><div style="flex:1"><div class="tiny muted">Amount due</div><div class="amt">' + S.fmtMoney(t.balance, inv.currency) + '</div></div><button class="btn primary" style="padding:13px 26px;font-size:15px" data-action="clientpay">' + icon('card') + 'Pay Now</button></div>' : '') +
        (st === 'paid' ? '<div class="pay-bar no-print"><div style="flex:1"><b style="color:var(--green-dark)">✓ Paid in full on ' + S.fmtDate(inv.paidAt) + '</b><div class="tiny muted">Receipt ' + S.receiptNumber(inv) + ' issued</div></div><button class="btn ghost" data-action="receipt">' + icon('file') + 'View receipt</button></div>' : ''),
      actions: {
        back: () => { location.hash = '#/invoices'; },
        edit: () => { location.hash = '#/invoices/' + inv.id + '/edit'; },
        pdf: () => window.print(),
        pay: () => payModal(inv.id),
        receipt: () => { location.hash = '#/r/' + inv.id; },
        clientpay: () => clientPayModal(inv.id)
      }
    };
  };

  function clientPayModal(id) {
    const inv = S.getInvoice(id); if (!inv) return;
    const t = S.computeTotals(inv);
    const cfg = S.db.settings.payments || {};
    const live = !!(cfg.paystackPublicKey);
    const body = live ?
      '<p class="small muted mb">Send your client a secure hosted checkout. They pay by card, bank transfer or mobile money via <b>Paystack</b>; the payment is verified server-side and this invoice is marked <b>Paid</b> automatically with a receipt.</p>' +
      '<div class="card card-b" style="background:var(--bg)"><div class="row small"><span class="muted" style="flex:1">Amount due</span><b class="tnum">' + S.fmtMoney(t.balance, inv.currency) + '</b></div>' +
      '<div class="row small"><span class="muted" style="flex:1">Client</span><b>' + esc((S.getClient(inv.clientId) || {}).name || '—') + '</b></div>' +
      '<div class="row small"><span class="muted" style="flex:1">Gateway</span><b>Paystack (' + esc(cfg.mode || 'live') + ')</b></div></div>' :
      '<p class="small muted mb">Record a payment received outside the app (cash, bank transfer, mobile money) or set up hosted online checkout in Settings ▸ Payments.</p>' +
      '<div class="grid" style="gap:8px" id="cp-methods">' + S.PAY_METHODS.map((p) => '<button class="method" data-m="' + p.id + '"><span class="mico" style="background:' + p.color + '">' + p.tag + '</span><span><b>' + p.label + '</b><div class="tiny muted">' + p.note + '</div></span></button>').join('') + '</div>' +
      '<div class="fgrid c2 mt"><div><label class="f">Amount received</label><input id="cp-amt" class="input" type="number" step="0.01" value="' + t.balance + '"></div><div style="display:flex;align-items:flex-end"><button class="btn ghost" id="cp-deposit" style="width:100%">50% deposit</button></div></div>';
    UI.openModal({
      title: (live ? 'Get paid — ' : 'Record payment — ') + S.fmtMoney(t.balance, inv.currency),
      body,
      footer: live ?
        '<button class="btn ghost" data-action="close-modal">Cancel</button><button class="btn primary" id="cp-link" style="padding:11px 22px">' + icon('link') + 'Create payment link</button>' :
        '<button class="btn ghost" data-action="close-modal">Cancel</button><button class="btn green" id="cp-pay" style="padding:11px 22px">' + icon('check') + 'Record payment</button>',
      mount: (m) => {
        if (live) {
          m.querySelector('#cp-link').addEventListener('click', async () => {
            const btn = m.querySelector('#cp-link'); btn.disabled = true; btn.innerHTML = 'Creating…';
            try {
              const link = await S.createPaymentLink(inv.id);
              UI.closeModal();
              UI.copyText(link).then(() => {});
              UI.openModal({
                title: 'Payment link ready',
                body: '<p class="small muted mb">Send this link to your client. When they pay, the invoice is marked <b>Paid</b> automatically and a receipt is issued on your next app open.</p>' +
                  '<div class="card card-b" style="word-break:break-all;font-size:12.5px;background:var(--bg)"><a href="' + esc(link) + '" target="_blank" rel="noopener">' + esc(link) + '</a></div>',
                footer: '<button class="btn ghost" data-action="close-modal">Close</button><button class="btn primary" id="cp-copy">' + icon('copy') + 'Copy link</button>',
                mount: (m2) => m2.querySelector('#cp-copy').addEventListener('click', () => UI.copyText(link).then((ok) => UI.toast(ok ? 'Link copied' : 'Copy blocked', ok ? 'green' : 'red', 'link')))
              });
            } catch (e) {
              btn.disabled = false; btn.innerHTML = icon('link') + 'Create payment link';
              UI.toast('Could not create link: ' + (e && e.message || 'check Settings ▸ Payments'), 'red');
            }
          });
          return;
        }
        let method = S.PAY_METHODS[0].id;
        m.querySelectorAll('#cp-methods .method').forEach((b) => b.addEventListener('click', () => { method = b.dataset.m; m.querySelectorAll('#cp-methods .method').forEach((x) => x.classList.remove('on')); b.classList.add('on'); }));
        m.querySelector('#cp-deposit').addEventListener('click', () => { m.querySelector('#cp-amt').value = (t.balance / 2).toFixed(2); });
        m.querySelector('#cp-pay').addEventListener('click', () => {
          const res = S.recordPayment(inv.id, m.querySelector('#cp-amt').value, method);
          UI.closeModal();
          if (!res) { UI.toast('Payment failed — check amount', 'red'); UI.render(); return; }
          UI.toast(res.receipt ? 'Paid in full — receipt ' + res.receipt : 'Partial payment recorded', 'green', 'check');
          UI.render();
        });
      }
    });
  }

  /* ================= RECEIPT ================= */
  UI.VIEWS.r = function (parts) {
    const inv = S.getInvoice(parts[1]);
    if (!inv) return { title: 'Not found', html: '<div class="empty">Receipt not found.</div>', actions: {} };
    const c = S.getClient(inv.clientId), b = S.db.settings.business, t = S.computeTotals(inv);
    const tpl = S.db.settings.template;
    const logo = b.logoDataUrl || 'assets/logo.png';
    document.title = S.receiptNumber(inv) + ' — SherPay';
    return {
      title: S.receiptNumber(inv),
      sub: 'Payment receipt',
      topActions: '<button class="btn ghost" data-action="back">' + icon('chevron', 'flip') + '<span class="hide-sm">Back</span></button><button class="btn ghost" data-action="pdf">' + icon('print') + '<span class="hide-sm">PDF</span></button><button class="btn primary" data-action="invoice">' + icon('invoice') + '<span class="hide-sm">Invoice</span></button>',
      html:
        '<div class="paper font-' + tpl.font + ' acc-' + tpl.accent + '">' +
          '<div class="paper-top"><div class="paper-brand"><img src="' + logo + '" alt=""><div><div class="bn">' + esc(b.name) + '</div><div class="ba">' + esc(b.address) + '</div></div></div>' +
          '<div class="paper-title"><h2 style="color:var(--green-dark)">RECEIPT</h2><div class="pnum">' + esc(S.receiptNumber(inv)) + '</div><div class="mt"><span class="badge paid">Paid</span></div></div></div>' +
          '<div class="paper-meta">' +
            '<div><div class="k">Received from</div><div class="v">' + esc(c ? c.name : '') + '\n' + esc(c ? c.address || '' : '') + '</div></div>' +
            '<div><div class="k">Invoice ref</div><div class="v">' + esc(inv.number) + '</div></div>' +
            '<div><div class="k">Date paid</div><div class="v">' + S.fmtDate(inv.paidAt) + '</div></div>' +
            '<div><div class="k">Currency</div><div class="v">' + inv.currency + '</div></div>' +
          '</div>' +
          '<table><thead><tr><th>Payment</th><th>Date</th><th>Method</th><th class="right">Amount</th></tr></thead><tbody>' +
          inv.payments.map((p) => { const m = S.PAY_METHODS.find((x) => x.id === p.method); return '<tr><td>Payment toward ' + esc(inv.number) + '</td><td>' + S.fmtDate(p.date) + '</td><td>' + esc(m ? m.label : p.method) + '</td><td class="right tnum">' + S.fmtMoney(p.amount, inv.currency) + '</td></tr>'; }).join('') +
          '</tbody></table>' +
          '<div class="paper-totals"><table>' +
            '<tr><td>Invoice total</td><td class="right tnum">' + S.fmtMoney(t.total, inv.currency) + '</td></tr>' +
            '<tr><td>Total received</td><td class="right tnum">' + S.fmtMoney(t.paid, inv.currency) + '</td></tr>' +
            '<tr class="grand"><td>Balance</td><td class="right tnum" style="color:var(--green-dark)">' + S.fmtMoney(t.balance, inv.currency) + '</td></tr>' +
          '</table></div>' +
          '<div class="paper-notes">Thank you for your payment. This receipt confirms settlement of invoice ' + esc(inv.number) + '. Records retained for 7 years per tax compliance.</div>' +
          '<div class="paper-foot"><img src="assets/logo.png" alt=""> Generated automatically by <b>SherPay</b></div>' +
        '</div>',
      actions: {
        // history.back() ejects users who opened the receipt link directly;
        // always land on the invoice view instead
        back: () => { location.hash = '#/i/' + inv.id; },
        pdf: () => window.print(),
        invoice: () => { location.hash = '#/i/' + inv.id; }
      }
    };
  };

  /* expose for cross-view calls */
  UI.VIEWS.invoices.__send = sendModal;
  UI.VIEWS.invoices.__pay = payModal;
})();

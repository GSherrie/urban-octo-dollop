/* ============ SherPay store: persistence, seed, money & date utils, automations ============ */
window.Store = (function () {
  const DB_KEY = 'sherpay_db_v1';

  const CURRENCIES = ['GHS','USD','EUR','GBP','NGN','KES','ZAR','CAD','AUD','INR','AED','JPY'];
  const CATEGORIES = ['Travel','Meals','Software','Office','Marketing','Equipment','Professional Fees','Other'];
  const PAY_METHODS = [
    { id:'card',    label:'Credit / Debit Card', note:'via Stripe', color:'#0B7CFF', tag:'CARD' },
    { id:'paypal',  label:'PayPal',              note:'paypal.com', color:'#0070BA', tag:'PP' },
    { id:'apple',   label:'Apple Pay',           note:'Touch / Face ID', color:'#111', tag:'Pay' },
    { id:'momo',    label:'Mobile Money',        note:'MTN · Vodafone · AirtelTigo', color:'#F5A524', tag:'MoMo' },
    { id:'bank',    label:'Bank Transfer',       note:'Manual reconciliation', color:'#0A2E5F', tag:'BNK' }
  ];

  /* ---------------- utils ---------------- */
  const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
  const num = (v) => { const n = parseFloat(v); return isFinite(n) ? n : 0; };
  const pad = (n, w) => String(n).padStart(w || 3, '0');
  const iso = (d) => d.toISOString().slice(0, 10);
  const todayISO = () => iso(new Date());
  const addDays = (dateStr, n) => { const d = new Date(dateStr + 'T00:00:00'); d.setDate(d.getDate() + n); return iso(d); };
  const addMonths = (dateStr, n) => { const d = new Date(dateStr + 'T00:00:00'); d.setMonth(d.getMonth() + n); return iso(d); };
  const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
  const fmtDate = (dateStr) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr + (dateStr.length === 10 ? 'T00:00:00' : ''));
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  };
  const fmtDateTime = (ts) => new Date(ts).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  const monthKey = (dateStr) => dateStr.slice(0, 7);
  const monthLabel = (key) => new Date(key + '-01T00:00:00').toLocaleDateString('en-GB', { month: 'short' });
  function fmtMoney(amount, currency) {
    try {
      return new Intl.NumberFormat('en-GB', { style: 'currency', currency: currency || 'USD', maximumFractionDigits: 2 }).format(amount);
    } catch (e) { return (currency || '') + ' ' + num(amount).toFixed(2); }
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

  /* ---------------- state ---------------- */
  let db = null;

  function save() {
    try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) { /* memory-only fallback */ }
  }
  function load() {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (raw) { db = JSON.parse(raw); return true; }
    } catch (e) {}
    return false;
  }

  /* ---------------- seed ---------------- */
  function seed() {
    const T = todayISO();
    const biz = {
      name: 'Sherline Studio',
      email: 'billing@sherline.studio',
      phone: '+233 30 274 8890',
      address: '14 Ring Road East\nAccra, Greater Accra\nGhana',
      logoDataUrl: null
    };
    const clients = [
      { id:'c1', name:'Accra Craft Markets Ltd', contact:'Ama Owusu', email:'ama@accracraft.gh', phone:'+233 24 555 0110', address:'Oxford Street, Osu\nAccra, Ghana', terms:14 },
      { id:'c2', name:'TechHub East London', contact:'James Whitfield', email:'accounts@techhub.co.uk', phone:'+44 20 7946 0810', address:'42 Shoreditch High St\nLondon E1 6JJ, UK', terms:30 },
      { id:'c3', name:'Volta Foods PLC', contact:'Kofi Mensah', email:'k.mensah@voltafoods.com', phone:'+233 20 555 7741', address:'Industrial Area\nTema, Ghana', terms:30 },
      { id:'c4', name:'Mensah & Co. Legal', contact:'Efua Mensah', email:'efua@mensahco.gh', phone:'+233 27 555 3322', address:'High Street\nCape Coast, Ghana', terms:7 }
    ];
    const inv = (n, clientId, issue, due, status, items, opts) => Object.assign({
      id: 'i' + n, number: 'INV-2026-' + pad(n), clientId, issueDate: issue, dueDate: due,
      currency: 'GHS', items, taxMode: 'percent', taxValue: 15, discountMode: 'none', discountValue: 0,
      status, payments: [], notes: 'Payment due within terms. Thank you for your business.', recurring: null,
      sentAt: null, viewedAt: null, paidAt: null, createdAt: Date.now()
    }, opts || {});

    const invoices = [
      inv(1, 'c2', addDays(T, -152), addDays(T, -122), 'paid',
        [{ desc:'Brand identity design — phase 1', qty:1, price:9500 }, { desc:'Design workshops (remote)', qty:3, price:800 }],
        { currency:'USD', payments:[{ id:'p1', date:addDays(T, -128), amount:11900, method:'bank' }], paidAt:addDays(T, -128), sentAt:addDays(T, -152) }),
      inv(2, 'c1', addDays(T, -96), addDays(T, -82), 'paid',
        [{ desc:'Marketplace app UI design', qty:24, price:420 }, { desc:'Prototype handoff', qty:1, price:1500 }],
        { payments:[{ id:'p2', date:addDays(T, -88), amount:6000, method:'momo' }, { id:'p3', date:addDays(T, -84), amount:5610, method:'card' }], paidAt:addDays(T, -84), sentAt:addDays(T, -96) }),
      inv(3, 'c3', addDays(T, -64), addDays(T, -34), 'paid',
        [{ desc:'Packaging design system', qty:1, price:14000 }, { desc:'Print production liaison', qty:6, price:650 }],
        { discountMode:'percent', discountValue:5, payments:[{ id:'p4', date:addDays(T, -40), amount:20413.5, method:'bank' }], paidAt:addDays(T, -40), sentAt:addDays(T, -64) }),
      inv(4, 'c2', addDays(T, -33), addDays(T, -3), 'viewed',
        [{ desc:'Brand identity design — phase 2', qty:1, price:8200 }, { desc:'Social media kit', qty:1, price:1200 }],
        { currency:'USD', sentAt:addDays(T, -33), viewedAt:addDays(T, -30) }),
      inv(5, 'c1', addDays(T, -18), addDays(T, -4), 'sent',
        [{ desc:'Pop-up stall signage set', qty:8, price:780 }, { desc:'Installation supervision', qty:2, price:900 }],
        { sentAt:addDays(T, -18) }),
      inv(6, 'c4', addDays(T, -9), addDays(T, +5), 'sent',
        [{ desc:'Legal-tech portal UX audit', qty:1, price:6400 }, { desc:'Usability testing sessions', qty:4, price:550 }],
        { payments:[{ id:'p5', date:addDays(T, -6), amount:4000, method:'card' }], sentAt:addDays(T, -9) }),
      inv(7, 'c3', T, addDays(T, 21), 'draft',
        [{ desc:'Annual report layout', qty:1, price:9800 }, { desc:'Photography art direction', qty:2, price:1400 }], {})
    ];
    const expenses = [
      { id:'e1', date:addDays(T, -71), merchant:'Uber Business', category:'Travel', tax:34.8, total:266.8, notes:'Client site visit, Tema' },
      { id:'e2', date:addDays(T, -58), merchant:'Figma', category:'Software', tax:4.5, total:34.5, notes:'Professional plan, monthly' },
      { id:'e3', date:addDays(T, -44), merchant:'Koala Restaurant', category:'Meals', tax:18.9, total:144.9, notes:'Client lunch — Volta Foods' },
      { id:'e4', date:addDays(T, -29), merchant:'Office Depot Accra', category:'Office', tax:26.1, total:200.1, notes:'Paper, toner, stationery' },
      { id:'e5', date:addDays(T, -15), merchant:'Google Ads', category:'Marketing', tax:52.2, total:400.2, notes:'Search campaign — August' },
      { id:'e6', date:addDays(T, -6), merchant:'Adobe Creative Cloud', category:'Software', tax:11.9, total:91.9, notes:'Annual renewal instalment' },
      { id:'e7', date:addDays(T, -2), merchant:'Bolt', category:'Travel', tax:12.0, total:92.0, notes:'Airport run — client pickup' }
    ];
    db = {
      version: 1,
      settings: {
        business: biz,
        currency: 'GHS',
        taxLabel: 'VAT', taxRate: 15,
        prefix: 'INV', seq: 8,
        template: { accent: 'blue', font: 'sans' },
        reminderDays: [3, 0, -3],
        hourlyRate: 450
      },
      clients, invoices, expenses,
      timeEntries: [],
      activity: [
        { id: uid(), ts: Date.now() - 86400000 * 6, type: 'paid', message: 'Invoice INV-2026-003 paid by Volta Foods PLC (Bank Transfer)' },
        { id: uid(), ts: Date.now() - 86400000 * 6 + 3600000, type: 'receipt', message: 'Receipt RCP-2026-003 generated and emailed to Volta Foods PLC' },
        { id: uid(), ts: Date.now() - 86400000 * 3, type: 'viewed', message: 'INV-2026-004 was viewed by TechHub East London' },
        { id: uid(), ts: Date.now() - 3600000 * 5, type: 'sent', message: 'INV-2026-007 drafted for Volta Foods PLC' }
      ]
    };
    save();
  }

  /* ---------------- selectors & calc ---------------- */
  const getClient = (id) => (db.clients.find((c) => c.id === id) || null);
  const getInvoice = (id) => (db.invoices.find((i) => i.id === id) || null);

  function computeTotals(inv) {
    const sub = (inv.items || []).reduce((s, it) => s + num(it.qty) * num(it.price), 0);
    const disc = inv.discountMode === 'percent' ? sub * num(inv.discountValue) / 100
      : inv.discountMode === 'flat' ? Math.min(num(inv.discountValue), sub) : 0;
    const base = sub - disc;
    const tax = inv.taxMode === 'percent' ? base * num(inv.taxValue) / 100
      : inv.taxMode === 'flat' ? num(inv.taxValue) : 0;
    const total = base + tax;
    const paid = (inv.payments || []).reduce((s, p) => s + num(p.amount), 0);
    return { sub, disc, tax, total, paid, balance: Math.max(0, +(total - paid).toFixed(2)) };
  }

  function displayStatus(inv) {
    const t = computeTotals(inv);
    if (inv.status === 'paid') return 'paid';
    if (t.paid > 0) return 'partial';
    if ((inv.status === 'sent' || inv.status === 'viewed') && inv.dueDate && daysBetween(todayISO(), inv.dueDate) < 0) return 'overdue';
    return inv.status;
  }
  const STATUS_LABEL = { draft:'Draft', sent:'Sent', viewed:'Viewed', paid:'Paid', overdue:'Overdue', partial:'Partially paid' };

  function newInvoiceNumber(issueDate) {
    const n = db.settings.seq++;
    const y = new Date((issueDate || todayISO()) + 'T00:00:00').getFullYear();
    return db.settings.prefix + '-' + y + '-' + pad(n);
  }

  function log(type, message) {
    db.activity.unshift({ id: uid(), ts: Date.now(), type, message });
    if (db.activity.length > 120) db.activity.length = 120;
  }

  /* ---------------- automations: reminders + recurring ---------------- */
  function runAutomations(silent) {
    let fired = 0;
    const offsets = (db.settings.reminderDays || []);
    db.invoices.forEach((inv) => {
      const st = displayStatus(inv);
      if ((st === 'sent' || st === 'viewed' || st === 'overdue' || st === 'partial') && inv.dueDate) {
        const daysToDue = daysBetween(todayISO(), inv.dueDate);
        offsets.forEach((off) => {
          if (daysToDue === off && !db.activity.some((a) => a.type === 'reminder' && a.ref === inv.id && a.off === off)) {
            const c = getClient(inv.clientId);
            db.activity.unshift({
              id: uid(), ts: Date.now(), type: 'reminder', ref: inv.id, off,
              message: 'Payment reminder emailed to ' + (c ? c.name : 'client') + ' for ' + inv.number +
                (off > 0 ? ' (' + off + ' days before due)' : off === 0 ? ' (due today)' : ' (' + Math.abs(off) + ' days overdue)')
            });
            fired++;
          }
        });
      }
      // recurring invoicing
      if (inv.recurring && inv.recurringNext && inv.recurringNext <= todayISO()) {
        const copy = JSON.parse(JSON.stringify(inv));
        copy.id = uid(); copy.number = newInvoiceNumber(todayISO());
        copy.issueDate = todayISO(); copy.dueDate = addDays(todayISO(), (getClient(inv.clientId) || { terms: 30 }).terms || 30);
        copy.status = 'sent'; copy.sentAt = todayISO(); copy.viewedAt = null; copy.paidAt = null; copy.payments = [];
        copy.recurringNext = addMonths(inv.recurringNext, 1);
        inv.recurringNext = copy.recurringNext;
        db.invoices.unshift(copy);
        log('recurring', 'Recurring invoice ' + copy.number + ' auto-generated from ' + inv.number);
        fired++;
      }
    });
    if (fired && !silent) save();
    return fired;
  }

  /* ---------------- mutations ---------------- */
  function recordPayment(invId, amount, method, date) {
    const inv = getInvoice(invId); if (!inv) return null;
    const t = computeTotals(inv);
    const amt = Math.min(num(amount), t.balance);
    if (amt <= 0) return null;
    inv.payments.push({ id: uid(), date: date || todayISO(), amount: +amt.toFixed(2), method });
    const after = computeTotals(inv);
    if (after.balance <= 0.009) { inv.status = 'paid'; inv.paidAt = todayISO(); }
    const m = PAY_METHODS.find((p) => p.id === method);
    log('paid', fmtMoney(amt, inv.currency) + ' received for ' + inv.number + ' (' + (m ? m.label : method) + ')');
    let receipt = null;
    if (inv.status === 'paid') {
      receipt = receiptNumber(inv);
      const c = getClient(inv.clientId);
      log('receipt', 'Receipt ' + receipt + ' generated and emailed to ' + (c ? c.name : 'client'));
    }
    save();
    return { receipt, balance: after.balance };
  }
  const receiptNumber = (inv) => 'RCP-' + inv.number.split('-').slice(1).join('-');

  function markSent(invId, channel) {
    const inv = getInvoice(invId); if (!inv) return;
    if (inv.status === 'draft') inv.status = 'sent';
    inv.sentAt = todayISO();
    const c = getClient(inv.clientId);
    log('sent', inv.number + ' sent to ' + (c ? c.name : 'client') + ' via ' + channel);
    save();
  }
  function markViewed(invId) {
    const inv = getInvoice(invId); if (!inv) return;
    if (inv.status === 'sent') {
      inv.status = 'viewed'; inv.viewedAt = todayISO();
      const c = getClient(inv.clientId);
      log('viewed', inv.number + ' was viewed by ' + (c ? c.name : 'client'));
      save();
    }
  }

  /* ---------------- reports ---------------- */
  function lastMonths(n) {
    const out = []; const d = new Date(); d.setDate(1);
    for (let i = n - 1; i >= 0; i--) { const x = new Date(d); x.setMonth(x.getMonth() - i); out.push(iso(x).slice(0, 7)); }
    return out;
  }
  function moneyByMonth() {
    const months = lastMonths(6);
    const rev = {}, exp = {};
    months.forEach((m) => { rev[m] = 0; exp[m] = 0; });
    db.invoices.forEach((inv) => (inv.payments || []).forEach((p) => {
      const m = monthKey(p.date); if (rev[m] !== undefined) rev[m] += num(p.amount);
    }));
    db.expenses.forEach((e) => { const m = monthKey(e.date); if (exp[m] !== undefined) exp[m] += num(e.total); });
    return { months, rev, exp };
  }
  function kpis() {
    const m = monthKey(todayISO());
    let outstanding = 0, paidMonth = 0, expMonth = 0, overdueCount = 0;
    db.invoices.forEach((inv) => {
      const t = computeTotals(inv); const st = displayStatus(inv);
      if (st !== 'paid' && st !== 'draft') outstanding += t.balance;
      if (st === 'overdue') overdueCount++;
      (inv.payments || []).forEach((p) => { if (monthKey(p.date) === m) paidMonth += num(p.amount); });
    });
    db.expenses.forEach((e) => { if (monthKey(e.date) === m) expMonth += num(e.total); });
    return { outstanding, paidMonth, expMonth, net: paidMonth - expMonth, overdueCount };
  }

  /* ---------------- export helpers ---------------- */
  function toCSV(rows) {
    return rows.map((r) => r.map((c) => {
      const s = String(c == null ? '' : c);
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(',')).join('\r\n');
  }
  function download(filename, text, mime) {
    const blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
  }

  function boot() {
    if (!load()) seed();
    runAutomations(true);
    save();
  }
  function resetDemo() { seed(); }

  return {
    get db() { return db; },
    set db(v) { db = v; },
    save, boot, resetDemo, seed,
    CURRENCIES, CATEGORIES, PAY_METHODS, STATUS_LABEL,
    uid, num, pad, iso, todayISO, addDays, addMonths, daysBetween, fmtDate, fmtDateTime, monthKey, monthLabel, fmtMoney, esc,
    getClient, getInvoice, computeTotals, displayStatus, newInvoiceNumber, log,
    runAutomations, recordPayment, markSent, markViewed, receiptNumber,
    lastMonths, moneyByMonth, kpis, toCSV, download
  };
})();
